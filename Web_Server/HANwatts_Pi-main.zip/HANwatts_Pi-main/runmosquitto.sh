mosquitto -c /home/pi/mosquitto.conf -d -v
exit 0