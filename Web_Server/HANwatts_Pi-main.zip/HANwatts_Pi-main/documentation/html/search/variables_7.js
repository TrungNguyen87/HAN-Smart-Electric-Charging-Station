var searchData=
[
  ['on_5fconnect',['on_connect',['../namespacemain3.html#a750e986d76cf0b4ce563501efc1d8f74',1,'main3.on_connect()'],['../namespace_s_q_lfunction.html#a215e7090f82fbf0d31fd97be6721389a',1,'SQLfunction.on_connect()']]],
  ['on_5fdisconnect',['on_disconnect',['../namespacemain3.html#afecee61e71845eda2bab29e6c6d4f91c',1,'main3.on_disconnect()'],['../namespace_s_q_lfunction.html#ab3031ccbbdb3f5a04bd7d66ceb4494c7',1,'SQLfunction.on_disconnect()']]]
];
