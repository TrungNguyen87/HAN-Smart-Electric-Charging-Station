var searchData=
[
  ['data',['data',['../namespacemain3.html#af3b593054c807ee934bbbca0f4964a15',1,'main3']]],
  ['data_5ferror',['Data_error',['../namespace_m_i_c3.html#a3e09291b9db0e529175f2c563a444764',1,'MIC3']]],
  ['dataref1',['dataRef1',['../namespacemain3.html#a49b33cac6f362fbef2ac40a65b883fde',1,'main3.dataRef1()'],['../namespace_s_q_lfunction.html#aab5e54d1ed091926790df37c8098f1f7',1,'SQLfunction.dataRef1()']]],
  ['datasend',['dataSend',['../namespacemain3.html#a5c3879d90e71304ff78e672fe925e10a',1,'main3']]],
  ['disconnect_5ftime',['DISCONNECT_TIME',['../namespace_s_q_lfunction.html#a68f53c3db854695a6e4a30a3a55594b4',1,'SQLfunction']]]
];
