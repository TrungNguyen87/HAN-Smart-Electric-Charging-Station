var searchData=
[
  ['send_5fadmin',['send_admin',['../namespace_s_q_lfunction.html#a75af8b1bb1aa60f32418ac7901b0060b',1,'SQLfunction']]],
  ['send_5femail',['send_email',['../namespace_s_q_lfunction.html#a526fa5bc764d15233b0cc1880fc33f83',1,'SQLfunction']]]
];
