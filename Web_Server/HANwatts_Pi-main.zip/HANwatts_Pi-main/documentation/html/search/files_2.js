var searchData=
[
  ['sqlfunction_2epy',['SQLfunction.py',['../_s_q_lfunction_8py.html',1,'']]]
];
