var searchData=
[
  ['time_5fsend',['time_send',['../namespacemain3.html#aefc1f762f0a9b87f47694cb1310cd460',1,'main3']]],
  ['trans_5ferror',['Trans_error',['../namespace_m_i_c3.html#a1fbc497007a26c1b2dbea6d293611157',1,'MIC3']]]
];
