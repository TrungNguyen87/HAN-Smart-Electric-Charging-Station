var searchData=
[
  ['bad_5fconnection_5fflag',['bad_connection_flag',['../namespacemain3.html#ab4939f18edc72dec9e72dfa3ec2f026b',1,'main3.bad_connection_flag()'],['../namespace_s_q_lfunction.html#abffdbb58f2363e73ea86ddc83a3893ad',1,'SQLfunction.bad_connection_flag()']]],
  ['broker',['broker',['../namespacemain3.html#afdf3bec321b3b9107003c09223640e80',1,'main3.broker()'],['../namespace_s_q_lfunction.html#aed5ec64d305ca004c4fe54d51dd36a4e',1,'SQLfunction.broker()']]]
];
