node-red -u /home/pi/node-red-1881 -p 1881
exit 0