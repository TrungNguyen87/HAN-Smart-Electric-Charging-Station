var annotated_dup =
[
    [ "JsonParserGeneratorRK", "namespace_json_parser_generator_r_k.html", "namespace_json_parser_generator_r_k" ],
    [ "JsonBuffer", "class_json_buffer.html", "class_json_buffer" ],
    [ "JsonModifier", "class_json_modifier.html", "class_json_modifier" ],
    [ "JsonParser", "class_json_parser.html", "class_json_parser" ],
    [ "JsonParserStatic", "class_json_parser_static.html", "class_json_parser_static" ],
    [ "JsonParserString", "class_json_parser_string.html", "class_json_parser_string" ],
    [ "JsonReference", "class_json_reference.html", "class_json_reference" ],
    [ "JsonWriter", "class_json_writer.html", "class_json_writer" ],
    [ "JsonWriterAutoArray", "class_json_writer_auto_array.html", "class_json_writer_auto_array" ],
    [ "JsonWriterAutoObject", "class_json_writer_auto_object.html", "class_json_writer_auto_object" ],
    [ "JsonWriterContext", "struct_json_writer_context.html", "struct_json_writer_context" ],
    [ "JsonWriterStatic", "class_json_writer_static.html", "class_json_writer_static" ],
    [ "MFRC522", "class_m_f_r_c522.html", "class_m_f_r_c522" ],
    [ "MQTT", "class_m_q_t_t.html", "class_m_q_t_t" ],
    [ "Print", "class_print.html", "class_print" ],
    [ "Printable", "class_printable.html", "class_printable" ],
    [ "Stream", "class_stream.html", "class_stream" ],
    [ "String", "class_string.html", "class_string" ],
    [ "StringPrintableHelper", "class_string_printable_helper.html", "class_string_printable_helper" ],
    [ "StringSumHelper", "class_string_sum_helper.html", "class_string_sum_helper" ]
];