var _commandparser_8h =
[
    [ "BUFSIZE", "_commandparser_8h.html#aeca034f67218340ecb2261a22c2f3dcd", null ],
    [ "DEBUGPORT", "_commandparser_8h.html#acbc24b500df51b97ae92c398a78f2257", null ],
    [ "RSTTIMEOUT", "_commandparser_8h.html#ae6f3a1996e8ab3a0b1f9a5354e41db0f", null ],
    [ "bytesArrToFloatArr", "_commandparser_8h.html#a7c2ba5e288dc8fd5bc2a455f375a223a", null ],
    [ "bytesToFloat", "_commandparser_8h.html#a358a8d73afde3c6af9f2fbef0c156cf0", null ],
    [ "readSerialOlimex", "_commandparser_8h.html#a37df00aa4f5618514442945d509f5029", null ],
    [ "Send", "_commandparser_8h.html#a068724586d37805bff056bcc3c6f02bf", null ],
    [ "stringParse", "_commandparser_8h.html#a5f5ebe01157b79c2f4383d42a3787168", null ],
    [ "buff", "_commandparser_8h.html#aade3a58aeb7b5fe4c36ef119e7027a5f", null ],
    [ "bufpos", "_commandparser_8h.html#a9ae77be080d462d041a52c377da64482", null ],
    [ "Current", "_commandparser_8h.html#ac7a5502c6bab0b1b7f3e1bd58546eb1e", null ],
    [ "CurrentList", "_commandparser_8h.html#acd950d6d9d76947b74823343a5f4a25d", null ],
    [ "Energy", "_commandparser_8h.html#aee63a73e17fd417c7562f2e5d7c81cb8", null ],
    [ "Frequency", "_commandparser_8h.html#ad8ee7ca82dcb110d2d5e32d73116b001", null ],
    [ "lastUpload", "_commandparser_8h.html#afbaeb9d17372ebc40b405fb8ce34dbbf", null ],
    [ "LineVoltage", "_commandparser_8h.html#a97cf7b62d84c77183146053465157cdc", null ],
    [ "numberOfZeroReadings", "_commandparser_8h.html#ab804d1dfcf90d1a4adf1b6417583e014", null ],
    [ "PhaseVoltage", "_commandparser_8h.html#a5455bcadf3414330eeedd39d97e8aee2", null ],
    [ "Power", "_commandparser_8h.html#ae0a1c20c390eb592307c92aa588bd232", null ],
    [ "readnextLine", "_commandparser_8h.html#a985b9d8e8f815d1ff6aca787d5782a94", null ]
];