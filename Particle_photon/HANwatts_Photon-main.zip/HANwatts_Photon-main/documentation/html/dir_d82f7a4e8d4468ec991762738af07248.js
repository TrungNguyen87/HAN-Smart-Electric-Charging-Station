var dir_d82f7a4e8d4468ec991762738af07248 =
[
    [ "module_info.o.d", "2_80_80_2photon_2obj_2src_2module__info_8o_8d.html", null ],
    [ "newlib_stubs.o.d", "2_80_80_2photon_2obj_2src_2newlib__stubs_8o_8d.html", null ],
    [ "user_export.o.d", "2_80_80_2photon_2obj_2src_2user__export_8o_8d.html", null ],
    [ "user_module.o.d", "2_80_80_2photon_2obj_2src_2user__module_8o_8d.html", null ]
];