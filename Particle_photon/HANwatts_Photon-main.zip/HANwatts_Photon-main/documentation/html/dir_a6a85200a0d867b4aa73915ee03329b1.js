var dir_a6a85200a0d867b4aa73915ee03329b1 =
[
    [ "MFRC522", "dir_8917d18e3e07827f87442dfed2a391c1.html", "dir_8917d18e3e07827f87442dfed2a391c1" ],
    [ "MFRC522.cpp", "_m_f_r_c522_8cpp.html", null ],
    [ "MFRC522.h", "_m_f_r_c522_8h.html", "_m_f_r_c522_8h" ]
];