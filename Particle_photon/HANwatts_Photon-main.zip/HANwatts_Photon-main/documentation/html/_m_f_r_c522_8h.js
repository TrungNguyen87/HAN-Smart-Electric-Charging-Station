var _m_f_r_c522_8h =
[
    [ "MFRC522", "class_m_f_r_c522.html", "class_m_f_r_c522" ],
    [ "Uid", "struct_m_f_r_c522_1_1_uid.html", "struct_m_f_r_c522_1_1_uid" ],
    [ "MIFARE_Key", "struct_m_f_r_c522_1_1_m_i_f_a_r_e___key.html", "struct_m_f_r_c522_1_1_m_i_f_a_r_e___key" ],
    [ "word", "_m_f_r_c522_8h.html#aacc262b7acb8ef2b1d38df8b855bc0f6", null ]
];