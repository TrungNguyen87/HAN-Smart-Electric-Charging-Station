var class_json_writer_static =
[
    [ "JsonWriterStatic", "class_json_writer_static.html#aef07dcd39c03c2f34566c84a3408f922", null ],
    [ "staticBuffer", "class_json_writer_static.html#af733d279f0980f674ce08c15f71cc358", null ]
];