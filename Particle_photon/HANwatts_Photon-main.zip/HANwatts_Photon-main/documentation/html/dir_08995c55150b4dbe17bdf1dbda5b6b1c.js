var dir_08995c55150b4dbe17bdf1dbda5b6b1c =
[
    [ "module_info.o.d", "1_85_82_2photon_2obj_2src_2module__info_8o_8d.html", null ],
    [ "newlib_stubs.o.d", "1_85_82_2photon_2obj_2src_2newlib__stubs_8o_8d.html", null ],
    [ "user_export.o.d", "1_85_82_2photon_2obj_2src_2user__export_8o_8d.html", null ],
    [ "user_module.o.d", "1_85_82_2photon_2obj_2src_2user__module_8o_8d.html", null ]
];