var searchData=
[
  ['_5f_5fspark_5fwiring_5fprint_5f',['__SPARK_WIRING_PRINT_',['../docs_2src_2spark__wiring__print_8h.html#a31cf2682ae26587a3c76b612b6d05337',1,'spark_wiring_print.h']]]
];
