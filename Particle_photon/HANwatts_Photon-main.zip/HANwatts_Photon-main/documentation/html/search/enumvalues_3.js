var searchData=
[
  ['demodreg',['DemodReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a37b01e93fff19ca62364e8f4f797a5c4',1,'MFRC522']]],
  ['divienreg',['DivIEnReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181afb4527cc3e364cce3fe3e62cdcde7da0',1,'MFRC522']]],
  ['divirqreg',['DivIrqReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a95e26d5ece97ae43c34d08797205a356',1,'MFRC522']]]
];
