var searchData=
[
  ['rfcfgreg',['RFCfgReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a0c99eea491c71e9d2a02bf8a86988adf',1,'MFRC522']]],
  ['rxgain_5f18db',['RxGain_18dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a4d5e7f6b74ce3912ffdf3305ea263497',1,'MFRC522']]],
  ['rxgain_5f18db_5f2',['RxGain_18dB_2',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335ac918bee80fae5c763094684ae08bff82',1,'MFRC522']]],
  ['rxgain_5f23db',['RxGain_23dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335aab1ac5ba97a5e07ff487f1996352a8e6',1,'MFRC522']]],
  ['rxgain_5f23db_5f2',['RxGain_23dB_2',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335ac3b5b39560b326ac91971a41ad167c15',1,'MFRC522']]],
  ['rxgain_5f33db',['RxGain_33dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a721f1c7082ea232324d8660844996158',1,'MFRC522']]],
  ['rxgain_5f38db',['RxGain_38dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335af2f57fe1d71de1d17204933084649368',1,'MFRC522']]],
  ['rxgain_5f43db',['RxGain_43dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335abc9602260b5733a23e0be7e0c03b1ec9',1,'MFRC522']]],
  ['rxgain_5f48db',['RxGain_48dB',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a13227ab5e3143489b0888671d284301b',1,'MFRC522']]],
  ['rxgain_5favg',['RxGain_avg',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a2b5b3bd5efdc06adc7c5e190919f5568',1,'MFRC522']]],
  ['rxgain_5fmax',['RxGain_max',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a3c59e553655b4e44c10d7deef54576a0',1,'MFRC522']]],
  ['rxgain_5fmin',['RxGain_min',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335a97ffca230ea898a78b5734ae0dd44506',1,'MFRC522']]],
  ['rxmodereg',['RxModeReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a7e0d6ae1fdd25be6d80d1b76b2274764',1,'MFRC522']]],
  ['rxselreg',['RxSelReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a669c0c9418d5437566b4b42da326c05f',1,'MFRC522']]],
  ['rxthresholdreg',['RxThresholdReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a50d7af7ddc6c606c2b3b9c07df2f22ab',1,'MFRC522']]]
];
