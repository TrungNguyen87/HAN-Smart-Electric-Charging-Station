var searchData=
[
  ['word',['word',['../_m_f_r_c522_8h.html#aacc262b7acb8ef2b1d38df8b855bc0f6',1,'MFRC522.h']]]
];
