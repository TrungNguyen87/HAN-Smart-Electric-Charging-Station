var searchData=
[
  ['uid',['Uid',['../struct_m_f_r_c522_1_1_uid.html',1,'MFRC522']]]
];
