var searchData=
[
  ['analogtestreg',['AnalogTestReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181af1d5966b064c10a672e0064d3ccc55c3',1,'MFRC522']]],
  ['autotestreg',['AutoTestReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a9583618ad17a8a20b7a735c7677c8e56',1,'MFRC522']]]
];
