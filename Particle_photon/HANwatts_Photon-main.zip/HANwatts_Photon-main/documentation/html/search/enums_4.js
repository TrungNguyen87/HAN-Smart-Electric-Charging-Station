var searchData=
[
  ['statuscode',['StatusCode',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27',1,'MFRC522']]]
];
