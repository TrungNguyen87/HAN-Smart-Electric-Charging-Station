var searchData=
[
  ['bufsize',['BUFSIZE',['../_commandparser_8h.html#aeca034f67218340ecb2261a22c2f3dcd',1,'Commandparser.h']]]
];
