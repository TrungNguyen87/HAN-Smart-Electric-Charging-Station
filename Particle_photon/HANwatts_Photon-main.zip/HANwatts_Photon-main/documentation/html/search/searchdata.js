var indexSectionsWithContent =
{
  0: "123_abcdefghijklmnopqrstuvw~",
  1: "jmpsu",
  2: "j",
  3: "123chjmnprstu",
  4: "_abcdefghijklmnoprstuvw~",
  5: "_bcdefhijklmnopqrstuw",
  6: "sw",
  7: "ejmps",
  8: "abcdefgjmpqrstvw",
  9: "jos",
  10: "_abcdeflmprsw",
  11: "jmpr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

