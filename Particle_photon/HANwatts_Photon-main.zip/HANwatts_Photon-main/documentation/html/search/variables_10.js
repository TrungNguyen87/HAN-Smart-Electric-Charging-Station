var searchData=
[
  ['readnextline',['readnextLine',['../_commandparser_8h.html#a985b9d8e8f815d1ff6aca787d5782a94',1,'Commandparser.h']]]
];
