var searchData=
[
  ['uid',['uid',['../class_m_f_r_c522.html#ad456545d41962dd7f8bd4210f5618498',1,'MFRC522']]],
  ['uidbyte',['uidByte',['../struct_m_f_r_c522_1_1_uid.html#a5581167c1e1c8beb98c44ff86f4fbc52',1,'MFRC522::Uid']]],
  ['uidtagcharger1',['UIDtagCharger1',['../2020__photon__code_8cpp.html#ad7696488afa62029edaf7487c0c32979',1,'2020_photon_code.cpp']]],
  ['uidtagcharger2',['UIDtagCharger2',['../2020__photon__code_8cpp.html#ae42c45149b41b8f8cee744bb45a607ea',1,'2020_photon_code.cpp']]]
];
