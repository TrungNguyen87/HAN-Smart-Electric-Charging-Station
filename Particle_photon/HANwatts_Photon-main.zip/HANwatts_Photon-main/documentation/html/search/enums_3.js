var searchData=
[
  ['pcd_5fcommand',['PCD_Command',['../class_m_f_r_c522.html#a973011639bbee6ad7035ae4dd49e2e07',1,'MFRC522']]],
  ['pcd_5fregister',['PCD_Register',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181',1,'MFRC522']]],
  ['pcd_5frxgain',['PCD_RxGain',['../class_m_f_r_c522.html#ab7e2bdb063a8ab5f8f29bd05e6867335',1,'MFRC522']]],
  ['picc_5fcommand',['PICC_Command',['../class_m_f_r_c522.html#a5d46a0e2b34b21f51f40ea95795b5e49',1,'MFRC522']]],
  ['picc_5ftype',['PICC_Type',['../class_m_f_r_c522.html#a3d8d44527557fe596a9ac486d49239de',1,'MFRC522']]]
];
