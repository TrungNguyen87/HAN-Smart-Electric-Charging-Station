var searchData=
[
  ['errorreg',['ErrorReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a240aa03a1d9542235b89cdef377a5796',1,'MFRC522']]]
];
