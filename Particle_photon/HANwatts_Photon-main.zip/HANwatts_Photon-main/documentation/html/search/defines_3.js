var searchData=
[
  ['chargeroffset',['CHARGEROFFSET',['../2020__photon__code_8cpp.html#aff16429df21a43a886f66fdbc1e850a1',1,'2020_photon_code.cpp']]]
];
