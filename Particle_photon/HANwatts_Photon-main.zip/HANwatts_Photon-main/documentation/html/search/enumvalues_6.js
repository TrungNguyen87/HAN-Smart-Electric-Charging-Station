var searchData=
[
  ['gsnreg',['GsNReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a2f81aa5f433fa51bb4b41cd8955de794',1,'MFRC522']]]
];
