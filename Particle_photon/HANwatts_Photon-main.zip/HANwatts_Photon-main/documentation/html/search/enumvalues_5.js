var searchData=
[
  ['fifodatareg',['FIFODataReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181afdbfd2f397b96d1043c808ec26e80328',1,'MFRC522']]],
  ['fifolevelreg',['FIFOLevelReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a35e5daf30358a0a271dadf50ba6bb4e7',1,'MFRC522']]]
];
