var searchData=
[
  ['endswith',['endsWith',['../class_string.html#af96a205cd68121b2fbdf01f5e9b9bb31',1,'String']]],
  ['equals',['equals',['../class_string.html#a1f8b83b7dfd47de4062abc3d57e4c351',1,'String::equals(const String &amp;s) const'],['../class_string.html#add7c8de5fdbebf0fba593d97535228c2',1,'String::equals(const char *cstr) const']]],
  ['equalsignorecase',['equalsIgnoreCase',['../class_string.html#a3b8832687edda189ae43632d70157b94',1,'String']]]
];
