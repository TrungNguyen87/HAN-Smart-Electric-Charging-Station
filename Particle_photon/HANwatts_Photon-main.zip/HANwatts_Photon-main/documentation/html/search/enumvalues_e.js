var searchData=
[
  ['versionreg',['VersionReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a4281c25cf6743163ed2e2f903cf17ba9',1,'MFRC522']]]
];
