var searchData=
[
  ['bitframingreg',['BitFramingReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181aaf8beb5a739cd8bf94b8b5c8d2d109ce',1,'MFRC522']]]
];
