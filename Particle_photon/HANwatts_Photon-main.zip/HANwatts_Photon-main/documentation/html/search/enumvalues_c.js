var searchData=
[
  ['serialspeedreg',['SerialSpeedReg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a23529258de3c3f5655afa2849f547f68',1,'MFRC522']]],
  ['status1reg',['Status1Reg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a9f8b10dda6868e74226ab7ccca8d5be0',1,'MFRC522']]],
  ['status2reg',['Status2Reg',['../class_m_f_r_c522.html#ae3b374c61bf50256289349fdb78fe181a8fb1a8c28b7a860793831566373f172f',1,'MFRC522']]],
  ['status_5fcollision',['STATUS_COLLISION',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a2ad63357ec8c38f712ea6fd811056993',1,'MFRC522']]],
  ['status_5fcrc_5fwrong',['STATUS_CRC_WRONG',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27ac25a91c2efa2dc7638758321374f7566',1,'MFRC522']]],
  ['status_5ferror',['STATUS_ERROR',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27aa3b0624b83ba5934292d671c73638a54',1,'MFRC522']]],
  ['status_5finternal_5ferror',['STATUS_INTERNAL_ERROR',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a851307266f677fd58db61540ffe76855',1,'MFRC522']]],
  ['status_5finvalid',['STATUS_INVALID',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a88d450f43a9d22ead5db926808599fb5',1,'MFRC522']]],
  ['status_5fmifare_5fnack',['STATUS_MIFARE_NACK',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27ad14f5e1a33047c90b50fa829cb669109',1,'MFRC522']]],
  ['status_5fno_5froom',['STATUS_NO_ROOM',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a45ce24f67052f4813df3b0f4efaafea8',1,'MFRC522']]],
  ['status_5fok',['STATUS_OK',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a3e34ac777020ad63ef7e346dfb813fe7',1,'MFRC522']]],
  ['status_5ftimeout',['STATUS_TIMEOUT',['../class_m_f_r_c522.html#ac0da61f475014ccb8c77205287a09c27a1db4d2ed757f0a638e5018fb994071ae',1,'MFRC522']]]
];
