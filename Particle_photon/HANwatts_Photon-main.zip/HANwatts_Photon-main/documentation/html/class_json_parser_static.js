var class_json_parser_static =
[
    [ "JsonParserStatic", "class_json_parser_static.html#a6d0aa92ea003e383a1efa1a8533e1e60", null ],
    [ "staticBuffer", "class_json_parser_static.html#a7098ca786f3e7ecacbe2824e49c4fc23", null ],
    [ "staticTokens", "class_json_parser_static.html#a46bd3b4c6e0d3205dfdcb6ef1e5dab8c", null ]
];